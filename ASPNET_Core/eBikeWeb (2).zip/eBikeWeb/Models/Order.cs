﻿namespace eBikeWeb.Models
{
    public class Order
    {
        public long id{ get; set; }
        public long ClientID{ get; set; }

        // 車型 樣式
        public string strStyle{ get; set; }

        // 車身 顏色
        public string strColor{ get; set; }

        // 出廠日期
        public DateTime dtFactoryManu{ get; set; }

        // 預定交車日期
        public DateTime dtReserveDeliver{ get; set; }

        // 售價
        public long nlPrice{ get; set; }

        // 加購選配
        public string strAddOptionalItems{ get; set; }

        // 加購選配金額
        public long nlOptionalItemPrice { get; set; }

        // 契約總金額
        public long nlContractTotal { get; set; }
    }
}
