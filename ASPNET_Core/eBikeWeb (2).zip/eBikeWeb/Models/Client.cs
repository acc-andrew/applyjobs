﻿namespace eBikeWeb.Models
{
    public class Client
    {
        public long id{ get; set; }
        public string strUsername{ get; set; }
        public string strPhoneNum{ get; set; }
        public string strUserAddress{ get; set; }
    }// public class Client
}
