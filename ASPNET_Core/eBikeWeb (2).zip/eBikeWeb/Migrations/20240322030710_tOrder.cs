﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace eBikeWeb.Migrations
{
    /// <inheritdoc />
    public partial class tOrder : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "tOrder",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ClientID = table.Column<long>(type: "bigint", nullable: false),
                    strStyle = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    strColor = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    dtFactoryManu = table.Column<DateTime>(type: "datetime2", nullable: false),
                    dtReserveDeliver = table.Column<DateTime>(type: "datetime2", nullable: false),
                    nlPrice = table.Column<long>(type: "bigint", nullable: false),
                    strAddOptionalItems = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    nlOptionalItemPrice = table.Column<long>(type: "bigint", nullable: false),
                    nlContractTotal = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tOrder", x => x.id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "tOrder");
        }
    }
}
