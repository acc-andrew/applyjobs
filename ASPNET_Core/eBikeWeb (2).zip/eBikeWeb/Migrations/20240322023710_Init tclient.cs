﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace eBikeWeb.Migrations
{
    /// <inheritdoc />
    public partial class Inittclient : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "tClient",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    strUsername = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    strPhoneNum = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    strUserAddress = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tClient", x => x.id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "tClient");
        }
    }
}
