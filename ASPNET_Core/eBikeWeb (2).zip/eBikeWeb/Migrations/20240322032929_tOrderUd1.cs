﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace eBikeWeb.Migrations
{
    /// <inheritdoc />
    public partial class tOrderUd1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "nlContract",
                table: "tOrder",
                newName: "nlContractTotal");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "nlContractTotal",
                table: "tOrder",
                newName: "nlContract");
        }
    }
}
