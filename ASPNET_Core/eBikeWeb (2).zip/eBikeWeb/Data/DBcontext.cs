﻿using eBikeWeb.Models;
using Microsoft.EntityFrameworkCore;

namespace eBikeWeb.Data
{
    public class DBcontext : DbContext
    {
        public DBcontext(DbContextOptions options) : base(options)
        {
        }

        // for Client table
        public DbSet<Client> tClient{ get; set; }

        // for Order table
        public DbSet<Order> tOrder{ get; set; }
    }
}
