const vm = Vue.createApp({
  data() {
    return {
      // 水餃種類
      chgWaterDumpling: 0,

      // 水餃個數
      nWaterDumplingLot: 0,

      // 水餃總價
      nTotalWaterDumpling: 0,

      // 水餃價錢
      eachWaterFumping: [6.5, 6.5, 5.5, 5.5, 5.5, 5.5, 8.0],

      // 煎餃價錢
      eachBoilFumping: [6.5, 6.5, 5.5, 5.5, 5.5, 5.5, 8.0],
    };
  },
  methods: {
    getTotalWaterDumpingPrice() {
      this.nTotalWaterDumpling =
        this.nWaterDumplingLot * this.eachWaterFumping[chgWaterDumpling];
      return `${this.nTotalWaterDumpling}`;
    },
  },
}).mount(".AreaWaterDumping");
